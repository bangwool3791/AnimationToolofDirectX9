// ChildForm.cpp : implementation file
//

#include "stdafx.h"
#include "Tool126.h"
#include "Tool126Doc.h"
#include "ChildForm.h"

// CChildForm

IMPLEMENT_DYNCREATE(CChildForm, CFormView)

CChildForm::CChildForm()
	: CFormView(IDD_DIALOG1)
{
}

CChildForm::~CChildForm()
{
}

void CChildForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO1, m_cbBone);
}

BEGIN_MESSAGE_MAP(CChildForm, CFormView)
	ON_BN_CLICKED(IDC_TEST_BUTTON, &CChildForm::OnBnClickedTestButton)
	ON_WM_CREATE()
	ON_WM_ACTIVATE()
END_MESSAGE_MAP()


// CChildForm diagnostics

#ifdef _DEBUG
void CChildForm::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CChildForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG

void CChildForm::OnBnClickedTestButton()
{
	MessageBox(L"Hello World");
}


int CChildForm::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}

void CChildForm::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	m_cbBone.AddString(KEY_BONE_ROOT);
	m_cbBone.AddString(KEY_BONE_PELVIS);
	m_cbBone.AddString(KEY_BONE_SPINE);
	m_cbBone.AddString(KEY_BONE_NECK);
	m_cbBone.AddString(KEY_BONE_LEFTLEG);
	m_cbBone.AddString(KEY_BONE_RIGHTLEG);
	m_cbBone.AddString(KEY_BONE_LEFTARM);
	m_cbBone.AddString(KEY_BONE_RIGHTARM);
	m_cbBone.AddString(KEY_BONE_LEFTELBOW);
	m_cbBone.AddString(KEY_BONE_RIGHTELBOW);
	m_cbBone.AddString(KEY_BONE_LEFTANKLE);
	m_cbBone.AddString(KEY_BONE_RIGHTANKLE);
	m_cbBone.SetCurSel(10);
}

void CChildForm::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CFormView::OnActivate(nState, pWndOther, bMinimized);
	// TODO: Add your message handler code here
}
