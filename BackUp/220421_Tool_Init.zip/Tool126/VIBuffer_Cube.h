#pragma once

#include "VIBuffer.h"



class CVIBuffer_Cube final : public CVIBuffer
{
public:
	CVIBuffer_Cube(LPDIRECT3DDEVICE9 pGraphicDevice);
	CVIBuffer_Cube(const CVIBuffer_Cube& rhs);
	virtual ~CVIBuffer_Cube() = default;

public:
	virtual HRESULT NativeConstruct_Prototype();
	virtual HRESULT NativeConstruct(void* pArg);

public:

protected:
	VTXTEX* pVertices = nullptr;
	FACEINDICES16* pIndices = nullptr;

public:
	static CVIBuffer_Cube* Create(LPDIRECT3DDEVICE9 pGraphicDevice);
	virtual CComponent* Clone(void* pArg);
	virtual void Free() override;
};
