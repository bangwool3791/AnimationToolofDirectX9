#pragma once
#include "afxcmn.h"
#include "afxwin.h"

// CChildForm form view

class CChildForm : public CFormView
{
	DECLARE_DYNCREATE(CChildForm)

	//Bone Key String
	const TCHAR* KEY_BONE_ROOT = L"Bone_Root";
	const TCHAR* KEY_BONE_PELVIS = L"Bone_Pelvis";
	const TCHAR* KEY_BONE_SPINE = L"Bone_Spine";
	const TCHAR* KEY_BONE_NECK = L"Bone_Neck";
	const TCHAR* KEY_BONE_LEFTLEG = L"Bone_LeftLeg";
	const TCHAR* KEY_BONE_RIGHTLEG = L"Bone_RightLeg";

	const TCHAR* KEY_BONE_LEFTARM = L"Bone_LeftArm";
	const TCHAR* KEY_BONE_RIGHTARM = L"Bone_RightArm";

	const TCHAR* KEY_BONE_LEFTELBOW = L"Bone_LeftElbow";
	const TCHAR* KEY_BONE_RIGHTELBOW = L"Bone_RightElbow";

	const TCHAR* KEY_BONE_LEFTANKLE = L"Bone_LeftAnkle";
	const TCHAR* KEY_BONE_RIGHTANKLE = L"Bone_RightAnkle";
public :
	const TCHAR* pBone[12] = { KEY_BONE_ROOT , KEY_BONE_PELVIS , KEY_BONE_SPINE , KEY_BONE_NECK , KEY_BONE_LEFTLEG ,
		KEY_BONE_RIGHTLEG , KEY_BONE_LEFTARM , KEY_BONE_RIGHTARM , KEY_BONE_LEFTELBOW , KEY_BONE_RIGHTELBOW ,
		KEY_BONE_LEFTANKLE ,
		KEY_BONE_RIGHTANKLE };
protected:
	CChildForm();          
	virtual ~CChildForm();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);   

	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
	afx_msg void OnBnClickedTestButton();
	CTreeCtrl m_treeBone;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	CComboBox m_cbBone;
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
};


