#pragma once
#include "Base.h"
#include "Layer.h"
#include "GameObject.h"


class CObject_Manager : public CBase
{
DECLARE_SINGLETON(CObject_Manager)
private:
	CObject_Manager();
	virtual ~CObject_Manager() = default;
public :
	void Tick(_float fDeltaTime);
	void Late_Tick(_float fDeltaTime);
	FORCEINLINE HRESULT	CObject_Manager::ReserveLayer(_uint _iLayerIndex)
	{
		if (m_ArrayLayer)
			return E_FAIL;

		m_ArrayLayer = new LAYER[_iLayerIndex];

		m_iLayerIndex = _iLayerIndex;

		return S_OK;
	}
	FORCEINLINE HRESULT		CObject_Manager::Add_ProtoObject(const _tchar* _ProtoTypeTag, CGameObject* _pGameObject)
	{
		if (NULL == _pGameObject || 0 >= lstrlen(_ProtoTypeTag))
			return E_FAIL;

		CGameObject* pInstance = Find_ProtoType(_ProtoTypeTag);

		if (pInstance)
		{
			MSGBOX(TEXT("Already ProtoType Object Created : CObject_Manager Add_ProtoObject"));
			return E_FAIL;
		}
		cout << "������Ÿ�� ��ü ���� �Ϸ� " << endl;
		m_MapProtoType.emplace(_ProtoTypeTag, _pGameObject);

		return S_OK;
	}

	HRESULT		CObject_Manager::Add_Layer(_uint _iLayerIndex, const _tchar* _LayerTag, const _tchar* _ProtoTypeTag, void* _pArg);
private :
	FORCEINLINE CGameObject* CObject_Manager::Find_ProtoType(const _tchar* _ProtoTypeTag);
	void*	 Find_Layer(_uint _iLayerIndex, const _tchar* _LayerTag);
private :
	map<const _tchar*, CGameObject*> m_MapProtoType;
	typedef map<const _tchar*, CGameObject*> PROTO;
	map<const _tchar*, CLayer*>*  m_ArrayLayer = nullptr;
	typedef map<const _tchar*, CLayer*>   LAYER;
	_uint	m_iLayerIndex = 0;
public :
	virtual void	Free() override;

	FORCEINLINE void CObject_Manager::Clear(_uint iLayerIndex)
	{
		if (!m_ArrayLayer[iLayerIndex].size())
			return;

		LAYER::iterator beginIter = m_ArrayLayer[iLayerIndex].begin();
		LAYER::iterator endIter = m_ArrayLayer[iLayerIndex].end();

		while (beginIter != endIter)
		{
			Safe_Release(beginIter->second);
			++beginIter;
		}

		m_ArrayLayer[iLayerIndex].swap(LAYER());
		m_ArrayLayer[iLayerIndex].clear();

		return;
	}
};