#include "stdafx.h"
#include "Test.h"
#include "GameInstance.h"

void CTest::Tick(_float _fDeltaTime)
{
	__super::Tick(_fDeltaTime);
	//_float3 vPos = m_pBoneRootTransForm->Get_State(Engine::STATE_POSITION);
	CGameInstance*		pGameInstance = CGameInstance::Get_Instance();
	if (nullptr == pGameInstance)
		return;

	Safe_AddRef(pGameInstance);

	_float  fDir = 0.f;
	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_ROOT))
		Set_Animation(ROOT, m_varr[ROOT], m_farr[ROOT], m_pBoneRootTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_PELVIS))
		Set_Animation(PELVIS, m_varr[PELVIS], m_farr[PELVIS], m_pBonePelvisTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_SPINE))
		Set_Animation(SPINE, m_varr[SPINE], m_farr[SPINE], m_pBoneSpineTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_NECK))
		Set_Animation(NECK, m_varr[NECK], m_farr[NECK], m_pBoneNeckTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_LEFTLEG))
		Set_Animation(LEFTLEG, m_varr[LEFTLEG], m_farr[LEFTLEG], m_pBoneLeftLegTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_RIGHTLEG))
		Set_Animation(RIGHTLEG, m_varr[RIGHTLEG], m_farr[RIGHTLEG], m_pBoneRightLegTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_LEFTARM))
		Set_Animation(LEFTARM, m_varr[LEFTARM], m_farr[LEFTARM], m_pBoneLeftArmTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_RIGHTARM))
		Set_Animation(RIGHTARM, m_varr[RIGHTARM], m_farr[RIGHTARM], m_pBoneRightArmTransForm);
	//Modifying
	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_LEFTELBOW))
		Set_Animation(LEFTELBOW, m_varr[LEFTELBOW], m_farr[LEFTELBOW], m_pBoneLeftElbowTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_RIGHTLBOW))
		Set_Animation(RIGHTELBOW, m_varr[RIGHTELBOW], m_farr[RIGHTELBOW], m_pBoneRightElbowTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_LEFTANKLE))
		Set_Animation(LEFTANKLE, m_varr[LEFTANKLE], m_farr[LEFTANKLE], m_pBoneLeftAnkleTransForm);

	if (m_vecTestState[m_eTestState].uMotion SHIFT_OPERATOR(INV_RIGHTANKLE))
		Set_Animation(RIGHTANKLE, m_varr[RIGHTANKLE], m_farr[RIGHTANKLE], m_pBoneRightAnkleTransForm);

	if (GetAsyncKeyState('W') < 0)
	{
		m_pBoneRootTransForm->Go_Straight(_fDeltaTime);
	}
	if (GetAsyncKeyState('S') < 0)
	{
		m_pBoneRootTransForm->Go_Backward(_fDeltaTime);
	}
	if (GetAsyncKeyState('A') < 0)
	{
		m_pBoneRootTransForm->Turn(_float3(0.f, 1.f, 0.f), _fDeltaTime);
	}
	if (GetAsyncKeyState('D') < 0)
	{
		m_pBoneRootTransForm->Turn(_float3(0.f, 1.f, 0.f), -_fDeltaTime);
	}

	if (m_vecTestState[m_eTestState].uFlag[ROOT] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[ROOT] >> INV_ANI_END & 0x01))
	{
		_float fResult = m_pBoneRootTransForm->Turn_Local(m_varr[ROOT], _fDeltaTime);

		switch (m_eTestState)
		{
		case TEST_STATE_ATTACK:
			if (fResult >= m_vecTestState[m_eTestState].fAngle[ROOT])
			{
				m_vecTestState[m_eTestState].uFlag[ROOT] |= (0x01 << INV_ANI_END);
			}
			break;
		}
	}

	if (m_vecTestState[m_eTestState].uFlag[SPINE] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[SPINE] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneSpineTransForm->Turn_Local(m_varr[SPINE], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[SPINE])
				{
					m_vecTestState[m_eTestState].uFlag[SPINE] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}


	if (m_vecTestState[m_eTestState].uFlag[PELVIS] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[PELVIS] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBonePelvisTransForm->Turn_Local(m_varr[PELVIS], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[PELVIS])
				{
					m_vecTestState[m_eTestState].uFlag[PELVIS] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (m_vecTestState[m_eTestState].uFlag[LEFTLEG] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[LEFTLEG] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneLeftLegTransForm->Turn_Local(m_varr[LEFTLEG], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[LEFTLEG])
				{
					m_vecTestState[m_eTestState].uFlag[LEFTLEG] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (m_vecTestState[m_eTestState].uFlag[RIGHTLEG] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[RIGHTLEG] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneRightLegTransForm->Turn_Local(m_varr[RIGHTLEG], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[RIGHTLEG])
				{
					m_vecTestState[m_eTestState].uFlag[RIGHTLEG] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (m_vecTestState[m_eTestState].uFlag[LEFTARM] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[LEFTARM] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneLeftArmTransForm->Turn_Local(m_varr[LEFTARM], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[LEFTARM])
				{
					m_vecTestState[m_eTestState].uFlag[LEFTARM] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (m_vecTestState[m_eTestState].uFlag[RIGHTARM] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[RIGHTARM] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneRightArmTransForm->Turn_Local(m_varr[RIGHTARM], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[RIGHTARM])
				{
					m_vecTestState[m_eTestState].uFlag[RIGHTARM] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}
	
	if (m_vecTestState[m_eTestState].uFlag[LEFTELBOW] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[LEFTELBOW] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneLeftElbowTransForm->Turn_Local(m_varr[LEFTELBOW], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[LEFTELBOW])
				{
					m_vecTestState[m_eTestState].uFlag[LEFTELBOW] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (m_vecTestState[m_eTestState].uFlag[RIGHTELBOW] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[RIGHTELBOW] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneRightElbowTransForm->Turn_Local(m_varr[RIGHTELBOW], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[RIGHTELBOW])
				{
					m_vecTestState[m_eTestState].uFlag[RIGHTELBOW] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (m_vecTestState[m_eTestState].uFlag[LEFTANKLE] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[LEFTANKLE] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneLeftAnkleTransForm->Turn_Local(m_varr[LEFTANKLE], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[LEFTANKLE])
				{
					m_vecTestState[m_eTestState].uFlag[LEFTANKLE] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (m_vecTestState[m_eTestState].uFlag[RIGHTANKLE] >> INV_ANI_SET & 0x01)
		if (!(m_vecTestState[m_eTestState].uFlag[RIGHTANKLE] >> INV_ANI_END & 0x01))
		{
			_float fResult = m_pBoneRightAnkleTransForm->Turn_Local(m_varr[RIGHTANKLE], _fDeltaTime);

			switch (m_eTestState)
			{
			case TEST_STATE_ATTACK:
				if (fResult >= m_vecTestState[m_eTestState].fAngle[RIGHTANKLE])
				{
					m_vecTestState[m_eTestState].uFlag[RIGHTANKLE] |= (0x01 << INV_ANI_END);
				}
				break;
			}
		}

	if (GetAsyncKeyState('1') < 0)
	{
		Clear_Flag(m_eTestState, _fDeltaTime);
		m_eTestState = TEST_STATE_STUN;
	}

	if (GetAsyncKeyState('2') < 0)
	{
		Clear_Flag(m_eTestState, _fDeltaTime);
		m_eTestState = TEST_STATE_ATTACK;
	}

	if (GetAsyncKeyState('3') < 0)
	{
		Clear_Flag(m_eTestState, _fDeltaTime);
		m_eTestState = TEST_STATE_IDLE;
	}
	
	//static _long MouseMove = 0;

	//if (MouseMove = pGameInstance->Get_DIMMoveState(CInput_Device::DIMM_X))
	//{
	//	m_pBoneRootTransForm->Turn(_float3(0.f, 1.f, 0.f), _fDeltaTime * MouseMove * 0.1f);
	//	MouseMove = 0;
	//}

	//if (MouseMove = pGameInstance->Get_DIMMoveState(CInput_Device::DIMM_Y))
	//{
	//	m_pBoneRootTransForm->Turn(m_pBoneRootTransForm->Get_State(STATE_RIGHT), _fDeltaTime * MouseMove * 0.1f);
	//	MouseMove = 0;
	//}

	Safe_Release(pGameInstance);
}

void CTest::Late_Tick(_float _fDeltaTime)
{
	__super::Late_Tick(_fDeltaTime);
	m_pRendererCom->Add_RenderList(Engine::RENDER_PRIORITY, this);
}

HRESULT CTest::Render()
{
	if (!m_pGraphicDev) //|| !m_pBoneRootCube || !m_pBonePelvisCube || !m_pBoneSpineCube)
		return E_FAIL;

	if (__super::Render())
		return E_FAIL;

	m_pBone->Render();
	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneNeckTransForm->Get_BindMatrix());
	m_pAniHeadCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneSpineTransForm->Get_BindMatrix());
	m_pAniBodyCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneLeftLegTransForm->Get_BindMatrix());
	m_pAniLeftLegCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneRightLegTransForm->Get_BindMatrix());
	m_pAniRightLegCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneLeftArmTransForm->Get_BindMatrix());
	m_pAniLeftArmCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneRightArmTransForm->Get_BindMatrix());
	m_pAniRightArmCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneLeftElbowTransForm->Get_BindMatrix());
	m_pAniLeftElbowCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneRightElbowTransForm->Get_BindMatrix());
	m_pAniRightElbowCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneLeftAnkleTransForm->Get_BindMatrix());
	m_pAniLeftAnkleCube->Render();

	m_pGraphicDev->SetTransform(D3DTS_WORLD, &m_pBoneRightAnkleTransForm->Get_BindMatrix());
	m_pAniRightAnkleCube->Render();

	return S_OK;
}

HRESULT CTest::NativeConstruct_Prototype()
{
	if (FAILED(__super::NativeConstruct_Prototype()))
		return E_FAIL;

	return S_OK;
}

HRESULT CTest::NativeConstruct(void* pArg)
{
	if (!m_pGraphicDev)
		return E_FAIL;

	if (FAILED(__super::NativeConstruct(pArg)))
		return E_FAIL;

	if (FAILED(SetUp_Components()))
		return E_FAIL;

	for (size_t i = 0; i < ANIMATION_STATE_END; ++i)
	{
		m_varr[i] = _float3(0.f, 0.f, 0.f);
		m_farr[i] = 0.f;
	}
	//1111 1111
	//root - pelvis - spine - neck - leftleg - rightleg - leftarm - rightarm
	//0001 1111
	//x axis - y axis - z axis - plus - minus
	//Set Trans class the Angle
	_float fAngle = 0.f;
	m_vecTestState.reserve(TEST_STATE_END);
	//���Ͽ����� ����ü�� �迭�� �޾ƿ´�.
	TEST_STRUCT stTest;
	ZeroMemory(&stTest, sizeof(TEST_STRUCT));
	stTest.uMotion = 0b000011110000;
	stTest.uDir[LEFTLEG] = (0x01 << INV_XAXIS) | (0x01 << INV_PLUS);
	stTest.uDir[RIGHTLEG] = (0x01 << INV_XAXIS) | (0x01 << INV_MINUS);
	stTest.uDir[LEFTARM] = (0x01 << INV_XAXIS) | (0x01 << INV_MINUS);
	stTest.uDir[RIGHTARM] = (0x01 << INV_XAXIS) | (0x01 << INV_PLUS);

	stTest.fAngle[LEFTLEG] = Engine::Math::PI / 3.f;
	stTest.fAngle[RIGHTLEG] = Engine::Math::PI / 3.f;
	stTest.fAngle[LEFTARM] = Engine::Math::PI / 3.f;
	stTest.fAngle[RIGHTARM] = Engine::Math::PI / 3.f;

	m_vecTestState.emplace_back(stTest);

	stTest.uMotion = 0b01010011;
	stTest.uDir[PELVIS] = (0x01 << INV_XAXIS) | (0x01 << INV_PLUS);
	stTest.fAngle[PELVIS] = Engine::Math::PI * 0.3;

	stTest.uDir[NECK] = (0x01 << INV_YAXIS) | (0x01 << INV_PLUS);
	stTest.fAngle[NECK] = Engine::Math::PI * 0.5;

	stTest.uDir[LEFTARM] = (0x01 << INV_XAXIS) | (0x01 << INV_ZAXIS) | (0x01 << INV_PLUS);
	stTest.fAngle[LEFTARM] = Engine::Math::PI * 0.3;

	stTest.uDir[RIGHTARM] = (0x01 << INV_XAXIS) | (0x01 << INV_ZAXIS) | (0x01 << INV_PLUS);
	stTest.fAngle[RIGHTARM] = Engine::Math::PI * 0.3;

	m_vecTestState.emplace_back(stTest);

	stTest.uMotion = 0x80;
	stTest.uDir[ROOT] = (0x01 << INV_XAXIS) | (0x01 << INV_PLUS);
	stTest.fAngle[ROOT] = Engine::Math::PI * 0.7;

	m_vecTestState.emplace_back(stTest);

	stTest.uMotion = 0x80;
	stTest.uDir[ROOT] = (0x01 << INV_XAXIS) | (0x01 << INV_PLUS);
	stTest.fAngle[ROOT] = Engine::Math::PI * 0.5;

	m_vecTestState.emplace_back(stTest);

	return S_OK;
}

HRESULT CTest::SetUp_Components()
{
	CGameInstance* pGameInstace = CGameInstance::Get_Instance();
	Safe_AddRef(pGameInstace);

	m_pRendererCom = (CRenderer*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_RENDERER, NULL);
	_float arrAniHeadRadius[4] = { 0.5f, 0.5f, -0.5f, 1.f };
	m_pAniHeadCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniHeadRadius);
	_float arrAniBodyRadius[4] = { 0.5f, 0.5f, -0.5f, 0.f };
	m_pAniBodyCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniBodyRadius);
	_float arrAniLeftLegRadius[4] = { 0.5f, 1.f, -1.f, -1.f };
	m_pAniLeftLegCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniLeftLegRadius);
	_float arrAniRightLegRadius[4] = { 0.5f, 1.f, -1.f, -1.f };
	m_pAniRightLegCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniRightLegRadius);
	_float arrAniLeftArmRadius[4] = { 0.5f, 1.f, -1.f, -1.f };
	m_pAniLeftArmCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniLeftArmRadius);
	_float arrAniRightArmRadius[4] = { 0.5f, 1.f, -1.f, -1.f };
	m_pAniRightArmCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniRightArmRadius);
	_float arrAniLeftElbowRadius[4] = { 0.5f, 0.5f, -0.5f, 1.f };
	m_pAniLeftElbowCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniLeftElbowRadius);
	_float arrAniRightElbowRadius[4] = { 0.5f, 0.5f, -0.5f, 1.f };
	m_pAniRightElbowCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniRightElbowRadius);
	_float arrAniLeftAnkleRadius[4] = { 0.5f, 0.5f, -0.5f, -1.f };
	m_pAniLeftAnkleCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniLeftAnkleRadius);
	_float arrAniRightAnkleRadius[4] = { 0.5f, 0.5f, -0.5f, -1.f };
	m_pAniRightAnkleCube = (CVIBuffer_Cube*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_VI_CUBE, arrAniRightAnkleRadius);

	if (NULL == m_pRendererCom)// || NULL == m_pBoneRootCube || NULL == m_pBonePelvisCube)
	{
		Safe_Release(m_pRendererCom);
		Safe_Release(pGameInstace);
		//Safe_Release(m_pBoneRootCube);
		//Safe_Release(m_pBonePelvisCube);
		//Safe_Release(m_pBoneSpineCube);
		MSGBOX(TEXT("Failed to Init CTest"));
		return E_FAIL;
	}

	m_pBone = g_pBone = (CBone*)pGameInstace->Clone_ComponentObject(0, Engine::KEY_COMPONENT_BONE, NULL);
	if (!m_pBone)
		return E_FAIL;
	//Width, Top, Bottom, Pos
	_float arrBoneRadius[4] = { 0.05f, 0.05f, -0.05f, 0.f };
	//�̰� �� Ŭ���� �ȿ��� �Լ�ȭ ��ų ��
	TRANSFORMDESC		TransformDesc;
	ZeroMemory(&TransformDesc, sizeof(TRANSFORMDESC));
	D3DXMatrixIdentity(&TransformDesc.LocalMatrix);
	D3DXMatrixIdentity(&TransformDesc.WorldMatrix);
	//add to root
	TransformDesc.vLocalPos = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;
	TransformDesc.vAxis = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	TransformDesc.fSpeedPerSec = 1.f;
	TransformDesc.fRotationPerSec = 1.f;
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_ROOT, TransformDesc, arrBoneRadius);
	m_pBoneRootTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_ROOT);
	Safe_AddRef(m_pBoneRootTransForm);

	//add to pelvis
	TransformDesc.vLocalPos = _float3{ 0.f, 1.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;//Engine::Math::PI * 0.5;
	TransformDesc.vAxis = _float3{ -1.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_PELVIS, TransformDesc, arrBoneRadius);
	m_pBonePelvisTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_PELVIS);
	Safe_AddRef(m_pBonePelvisTransForm);
	//add to spine
	TransformDesc.vLocalPos = _float3{ 0.f, 1.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;
	TransformDesc.vAxis = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_SPINE, TransformDesc, arrBoneRadius);
	m_pBoneSpineTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_SPINE);
	Safe_AddRef(m_pBoneSpineTransForm);
	//add to Neck
	TransformDesc.vLocalPos = _float3{ 0.f, 1.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;
	TransformDesc.vAxis = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_NECK, TransformDesc, arrBoneRadius);
	m_pBoneNeckTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_NECK);
	Safe_AddRef(m_pBoneNeckTransForm);
	//add to LeftLeg
	TransformDesc.vLocalPos = _float3{ 1.f, 0.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;
	TransformDesc.vAxis = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTLEG, TransformDesc, arrBoneRadius);
	m_pBoneLeftLegTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTLEG);
	Safe_AddRef(m_pBoneLeftLegTransForm);
	//add to RightLeg
	TransformDesc.vLocalPos = _float3{ 1.f * -1.f, 0.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;
	TransformDesc.vAxis = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTLEG, TransformDesc, arrBoneRadius);
	m_pBoneRightLegTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTLEG);
	Safe_AddRef(m_pBoneRightLegTransForm);
	//add to LeftArm
	TransformDesc.vLocalPos = _float3{ 1.f, 1.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;
	TransformDesc.vAxis = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTARM, TransformDesc, arrBoneRadius);
	m_pBoneLeftArmTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTARM);
	Safe_AddRef(m_pBoneLeftArmTransForm);
	//add to RightArm
	TransformDesc.vLocalPos = _float3{ 1.f * -1.f, 1.f, 0.f };
	TransformDesc.fLocalAngle = 0.f;
	TransformDesc.vAxis = _float3{ 0.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTARM, TransformDesc, arrBoneRadius);
	m_pBoneRightArmTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTARM);
	Safe_AddRef(m_pBoneRightArmTransForm);
	//Left Elbow
	TransformDesc.vLocalPos = _float3{ 0.f, -1.5f, 0.f };
	TransformDesc.fLocalAngle = Engine::Math::PI * 0.5f;
	TransformDesc.vAxis = _float3{ 1.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTELBOW, TransformDesc, arrBoneRadius);
	m_pBoneLeftElbowTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTELBOW);
	Safe_AddRef(m_pBoneLeftElbowTransForm);
	//Right Elbow
	TransformDesc.vLocalPos = _float3{ 0.f, -1.5f, 0.f };
	TransformDesc.fLocalAngle = Engine::Math::PI * 0.5f;
	TransformDesc.vAxis = _float3{ 1.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTELBOW, TransformDesc, arrBoneRadius);
	m_pBoneRightElbowTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTELBOW);
	Safe_AddRef(m_pBoneRightElbowTransForm);
	//Left Elbow
	TransformDesc.vLocalPos = _float3{ 0.f, -1.5f, 0.f };
	TransformDesc.fLocalAngle = Engine::Math::PI * 0.5f;
	TransformDesc.vAxis = _float3{ 1.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTANKLE, TransformDesc, arrBoneRadius);
	m_pBoneLeftAnkleTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTANKLE);
	Safe_AddRef(m_pBoneLeftAnkleTransForm);
	//Right Elbow
	TransformDesc.vLocalPos = _float3{ 0.f, -1.5f, 0.f };
	TransformDesc.fLocalAngle = Engine::Math::PI * 0.5f;
	TransformDesc.vAxis = _float3{ 1.f, 0.f, 0.f };
	TransformDesc.LocalMatrix = Set_Matrix(TransformDesc.vLocalPos, TransformDesc.vAxis, TransformDesc.fLocalAngle);
	m_pBone->Add_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTANKLE, TransformDesc, arrBoneRadius);
	m_pBoneRightAnkleTransForm = (CTransform*)m_pBone->Find_Bone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTANKLE);
	Safe_AddRef(m_pBoneRightAnkleTransForm);
	//bine root

	//bind pelvis
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_ROOT, Engine::KEY_BONE_PELVIS);
	//bind spine
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_PELVIS, Engine::KEY_BONE_SPINE);
	//bind neck
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_SPINE, Engine::KEY_BONE_NECK);
	//bind left leg
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_PELVIS, Engine::KEY_BONE_LEFTLEG);
	//bind right leg
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_PELVIS, Engine::KEY_BONE_RIGHTLEG);
	//bind right arm
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_SPINE, Engine::KEY_BONE_LEFTARM);
	//bind right leg
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_SPINE, Engine::KEY_BONE_RIGHTARM);
	//bind left elbow
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTARM, Engine::KEY_BONE_LEFTELBOW);
	//bind right elbow
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTARM, Engine::KEY_BONE_RIGHTELBOW);
	//bind left ankle
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_LEFTLEG, Engine::KEY_BONE_LEFTANKLE);
	//bind right ankle
	m_pBone->Setting_ParentBone(BONE_LAYER_PLAYER, Engine::KEY_BONE_RIGHTLEG, Engine::KEY_BONE_RIGHTANKLE);
	//Release local component
	Safe_AddRef(m_pRendererCom);
	Safe_Release(pGameInstace);
	return S_OK;
}

CTest* CTest::Clone(void* pArg)
{
	CTest * pInstance = new CTest(*this);

	if (!pInstance)
		return NULL;

	if (FAILED(pInstance->NativeConstruct(pArg)))
		return NULL;

	//if (FAILED(m_pBoneRootCube->NativeConstruct(pArg)))
	//{
	//	
	//}
	return pInstance;
}

void CTest::Free()
{
	cout << "[CTest Free]" << endl;
	__super::Free();
	Safe_Release(m_pRendererCom);

	//Release Cube
	//Safe_Release(m_pBoneRootCube);
	//Safe_Release(m_pBonePelvisCube);
	//Safe_Release(m_pBoneSpineCube);
	//Safe_Release(m_pBoneSpineCube);
	//
	////Release Transform
	//Safe_Release(m_pBonePelvisTransForm);
	//Safe_Release(m_pBoneRootTransForm);
	//Safe_Release(m_pBoneSpineTransForm);

	Safe_Release(m_pBoneRootTransForm);

	Safe_Release(m_pBonePelvisTransForm);

	Safe_Release(m_pBoneSpineTransForm);

	Safe_Release(m_pBoneNeckTransForm);

	Safe_Release(m_pBoneLeftLegTransForm);

	Safe_Release(m_pBoneRightLegTransForm);

	Safe_Release(m_pBoneLeftArmTransForm);

	Safe_Release(m_pBoneRightArmTransForm);

	Safe_Release(m_pBoneLeftElbowTransForm);
	Safe_Release(m_pBoneRightElbowTransForm);

	Safe_Release(m_pBoneLeftAnkleTransForm);
	Safe_Release(m_pBoneRightAnkleTransForm);
	//Release Bone
	Safe_Release(m_pBone);

	Safe_Release(m_pAniHeadCube);
	Safe_Release(m_pAniBodyCube);
	Safe_Release(m_pAniLeftLegCube);
	Safe_Release(m_pAniRightLegCube);
	Safe_Release(m_pAniLeftArmCube);
	Safe_Release(m_pAniRightArmCube);
	Safe_Release(m_pAniLeftElbowCube);
	Safe_Release(m_pAniRightElbowCube);
	Safe_Release(m_pAniLeftAnkleCube);
	Safe_Release(m_pAniRightAnkleCube);
}