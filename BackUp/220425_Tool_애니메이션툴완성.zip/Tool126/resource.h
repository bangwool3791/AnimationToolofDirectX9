//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Tool126.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Tool126TYPE                 130
#define IDD_DIALOG1                     310
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_TEST_BUTTON                 1001
#define IDC_THREAD_BUTTON               1001
#define IDC_BONE_TREE                   1002
#define IDC_COMBO1                      1003
#define CB_ROOT_BONE_AXIS               1003
#define IDC_ANIMATION_TREE              1004
#define CB_ANI_SELECT_BODY_BONE         1005
#define IDC_SPIN1                       1006
#define SPIN_ROOT_BONE_POS_X            1006
#define IDC_EDIT2                       1007
#define IDC_ROOT_BONE_POS               1007
#define EIDT_ROOT_BONE_POS_X            1007
#define EDIT_BONE_ANGLE                 1008
#define SPIN_ANIMATION_WIDTH            1009
#define EDIT_ANIMATION_WIDTH            1010
#define IDC_RADIO1                      1011
#define CB_ANI_SELECT_ANI               1011
#define SPIN_ROOT_BONE_POS_Y            1012
#define EIDT_ROOT_BONE_POS_Y            1013
#define SPIN_ROOT_BONE_POS_Z            1014
#define EIDT_ROOT_BONE_POS_Z            1015
#define SPIN_ROOT_BONE_POS_Z2           1016
#define SPIN_BONE_ANGLE                 1016
#define SPIN_ANIMATION_HEIGHT           1017
#define SPIN_ANIMATION_TOP              1017
#define EDIT_ANIMATION_HEIGHT           1018
#define EDIT_ANIMATION_TOP              1018
#define SPIN_ROOT_BONE_POS_Z3           1019
#define EDIT_ANIMATION_POS              1020
#define SPIN_ANIMATION_POS              1020
#define SPIN_ROOT_BONE_BOTTOM           1021
#define SPIN_ANIMATION_BOTTOM           1022
#define IDC_RADIO2                      1023
#define CHECK_ROOT                      1023
#define IDC_RADIO3                      1024
#define IDC_RADIO4                      1025
#define IDC_SAVE_BUTTON                 1025
#define IDC_RADIO5                      1026
#define IDC_RADIO6                      1027
#define IDC_SAVE_BUTTON2                1027
#define IDC_LOAD_BUTTON                 1027
#define IDC_RADIO7                      1028
#define IDC_RADIO8                      1029
#define IDC_RADIO9                      1030
#define IDC_RADIO10                     1031
#define RADIO_ANI_AXIS_1                1037
#define RADIO_ANI_AXIS_2                1038
#define RADIO_ANI_AXIS_3                1039
#define RADIO_ANI_DIR_1                 1040
#define RADIO_ANI_DIR_2                 1041
#define SPIN_ANIMATION_MAX_ANGLE        1042
#define EIDT__ANIMATION_MAX_ANGLE       1043
#define SPIN_ANIMATION_MAX_ANGLE2       1044
#define SPIN_ANIMATION_MIN_ANGLE        1044
#define EIDT__ANIMATION_MIN_ANGLE       1045
#define CHECK_PELVIS                    1046
#define CHECK_SPINE                     1047
#define CHECK_NECK                      1048
#define CHECK_LEFTLEG                   1049
#define CHECK_RIGHTLEG                  1050
#define CHECK_LEFTARM                   1051
#define CHECK_RIGHTARM                  1052
#define CHECK_LEFTELBOW                 1053
#define CHECK_RIGHTELBOW                1054
#define CHECK_LEFTANKLE                 1055
#define CHECK_RIGHTANKLE                1056

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
