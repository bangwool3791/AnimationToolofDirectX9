#pragma once

#define			WINCX		800
#define			WINCY		600

#define			CHILD_WINCX	 500	

#define			PURE		= 0

#define			OBJ_NOEVENT		0
#define			OBJ_DEAD		1

#define			VK_MAX			0xff

#define			TILECX			64
#define			TILECY			64

#define			TILEX			30
#define			TILEY			20
