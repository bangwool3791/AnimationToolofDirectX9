#include "stdafx.h"
#include "Parser.h"

CParser::~CParser()
{
}
