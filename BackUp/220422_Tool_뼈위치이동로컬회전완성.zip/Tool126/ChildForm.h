#pragma once
#include "afxcmn.h"
#include "afxwin.h"

// CChildForm form view
#include "Transform.h"
class CChildForm : public CFormView
{
	DECLARE_DYNCREATE(CChildForm)

	//Bone Key String
	const TCHAR* KEY_BONE_ROOT = L"Bone_Root";
	const TCHAR* KEY_BONE_PELVIS = L"Bone_Pelvis";
	const TCHAR* KEY_BONE_SPINE = L"Bone_Spine";
	const TCHAR* KEY_BONE_NECK = L"Bone_Neck";
	const TCHAR* KEY_BONE_LEFTLEG = L"Bone_LeftLeg";
	const TCHAR* KEY_BONE_RIGHTLEG = L"Bone_RightLeg";

	const TCHAR* KEY_BONE_LEFTARM = L"Bone_LeftArm";
	const TCHAR* KEY_BONE_RIGHTARM = L"Bone_RightArm";

	const TCHAR* KEY_BONE_LEFTELBOW = L"Bone_LeftElbow";
	const TCHAR* KEY_BONE_RIGHTELBOW = L"Bone_RightElbow";

	const TCHAR* KEY_BONE_LEFTANKLE = L"Bone_LeftAnkle";
	const TCHAR* KEY_BONE_RIGHTANKLE = L"Bone_RightAnkle";
public :
	const TCHAR* pBone[12] = { KEY_BONE_ROOT , KEY_BONE_PELVIS , KEY_BONE_SPINE , KEY_BONE_NECK , KEY_BONE_LEFTLEG ,
		KEY_BONE_RIGHTLEG , KEY_BONE_LEFTARM , KEY_BONE_RIGHTARM , KEY_BONE_LEFTELBOW , KEY_BONE_RIGHTELBOW ,
		KEY_BONE_LEFTANKLE ,
		KEY_BONE_RIGHTANKLE };
protected:
	CChildForm();          
	virtual ~CChildForm();
public :
private :
	unsigned int m_iBoneIndex = 0;
	vector<CTransform*> m_vecBone;
private :
	HTREEITEM TreeBoneItem = NULL;
	HTREEITEM TreePelvisItem = NULL;
	HTREEITEM TreeSpineItem = NULL;
	HTREEITEM TreeNeckItem = NULL;
	HTREEITEM TreeLeftLegItem = NULL;
	HTREEITEM TreeRightLegItem = NULL;
	HTREEITEM TreeLeftArmItem = NULL;
	HTREEITEM TreeRightArmItem = NULL;
	HTREEITEM TreeLeftElbowItem = NULL;
	HTREEITEM TreeRightElbowItem = NULL;
	HTREEITEM TreeLeftAnkleItem = NULL;
	HTREEITEM TreeRightAnkleItem = NULL;
private :
public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif
private :
	bool CChildForm::isDigit(CString EditStr , CString& _string)
	{
		int count = EditStr.GetLength();
		int i = 0;
		for ( i = 0; i < count; ++i)
		{
			char temp = EditStr.GetAt(i);

			if (i == 0 && temp == '-')
				continue;

			if(temp >= '0' && temp <= '9')
				continue;
			else break;
		}

		if (i == count)
		{
			_string = EditStr;
			return true;
		}
		else
		{
			return false;
		}
	}
protected:
	virtual void DoDataExchange(CDataExchange* pDX);   

	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
	afx_msg void OnBnClickedTestButton();
	CTreeCtrl m_treeBone;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	CComboBox m_cbBone;
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnTvnSelchangedBoneTree(NMHDR *pNMHDR, LRESULT *pResult);

	CEdit m_tbRootBonePosX;
	CString m_strRootBonePosX;

	CEdit m_tbRootBonePosY;
	CString m_strRootBonePosY;

	CEdit m_tbRootBonePosZ;
	CString m_strRootBonePosZ;
	CSpinButtonCtrl m_SpinRootBonePosX;

	D3DXVECTOR3 m_vBoneLocalAxis;
	afx_msg void OnDeltaposRootBonePosX(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnDeltaposRootBonePosY(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnDeltaposRootBonePosZ(NMHDR *pNMHDR, LRESULT *pResult);

	CSpinButtonCtrl m_SpinRootBonePosZ;
	CSpinButtonCtrl m_SpinRootBonePosY;

	void CChildForm::AllowOnlyRealNum(CEdit *cedit, bool minus, CString& _String);
	//CString CChildForm::GetRealNum(float fVal, bool minus, CString _String);
	afx_msg void OnEnChangeRootBonePosX();
	afx_msg void OnEnChangeRootBonePosY();
	afx_msg void OnEnChangeRootBonePosZ();
	CComboBox cb_boneAxis;
	//Bone Angle
	CEdit m_tbBoneAngle;
	CSpinButtonCtrl m_SpinBoneAngle;
	CString m_strBoneAngle;
	float	m_fBoneLocalAngle = 0.f;
	afx_msg void OnEnChangeBoneAngle();
	afx_msg void OnDeltaposBoneAngle(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnCbnSelchangeRootBoneAxis();
	afx_msg void OnCbnEditupdateRootBoneAxis();
	afx_msg void OnCbnDropdownRootBoneAxis();
};


