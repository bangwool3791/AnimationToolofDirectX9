// ChildForm.cpp : implementation file
//

#include "stdafx.h"
#include "Tool126.h"
#include "Tool126Doc.h"
#include "Tool126View.h"
extern CRITICAL_SECTION g_CriticalSection;
#include "ChildForm.h"

// CChildForm

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CChildForm, CFormView)

#include "Test.h"
extern vector<CTransform*> g_vecBoneTransfrom;
CChildForm::CChildForm()
	: CFormView(IDD_DIALOG1)
{
	ZeroMemory(&m_vBoneLocalAxis, sizeof(D3DXVECTOR3));
}

CChildForm::~CChildForm()
{
}

void CChildForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BONE_TREE, m_treeBone);
	TreeBoneItem = m_treeBone.InsertItem(KEY_BONE_ROOT);
	TreePelvisItem = m_treeBone.InsertItem(KEY_BONE_PELVIS);
	TreeSpineItem = m_treeBone.InsertItem(KEY_BONE_SPINE);
	TreeNeckItem = m_treeBone.InsertItem(KEY_BONE_NECK);
	TreeLeftLegItem = m_treeBone.InsertItem(KEY_BONE_LEFTLEG);
	TreeRightLegItem = m_treeBone.InsertItem(KEY_BONE_RIGHTLEG);
	TreeLeftArmItem = m_treeBone.InsertItem(KEY_BONE_LEFTARM);
	TreeRightArmItem = m_treeBone.InsertItem(KEY_BONE_RIGHTARM);
	TreeLeftElbowItem = m_treeBone.InsertItem(KEY_BONE_LEFTELBOW);
	TreeRightElbowItem = m_treeBone.InsertItem(KEY_BONE_RIGHTELBOW);
	TreeLeftAnkleItem = m_treeBone.InsertItem(KEY_BONE_LEFTANKLE);
	TreeRightAnkleItem = m_treeBone.InsertItem(KEY_BONE_RIGHTANKLE);
	DDX_Control(pDX, EIDT_ROOT_BONE_POS_X, m_tbRootBonePosX);
	DDX_Control(pDX, SPIN_ROOT_BONE_POS_X, m_SpinRootBonePosX);
	DDX_Control(pDX, EIDT_ROOT_BONE_POS_Y, m_tbRootBonePosY);
	DDX_Control(pDX, SPIN_ROOT_BONE_POS_Y, m_SpinRootBonePosY);
	DDX_Control(pDX, EIDT_ROOT_BONE_POS_Z, m_tbRootBonePosZ);
	DDX_Control(pDX, SPIN_ROOT_BONE_POS_Z, m_SpinRootBonePosZ);

	m_tbRootBonePosX.SetWindowTextW(TEXT("0.0"));
	m_SpinRootBonePosX.SetRange(-100, 100);
	m_SpinRootBonePosX.SetPos(0);

	m_tbRootBonePosY.SetWindowTextW(TEXT("0.0"));
	m_SpinRootBonePosY.SetRange(-100, 100);
	m_SpinRootBonePosY.SetPos(0);

	m_tbRootBonePosZ.SetWindowTextW(TEXT("0.0"));
	m_SpinRootBonePosZ.SetRange(-100, 100);
	m_SpinRootBonePosZ.SetPos(0);

	DDX_Control(pDX, CB_ROOT_BONE_AXIS, cb_boneAxis);
	DDX_Control(pDX, EDIT_BONE_ANGLE, m_tbBoneAngle);
	DDX_Control(pDX, SPIN_BONE_ANGLE, m_SpinBoneAngle);
	m_tbBoneAngle.SetWindowTextW(TEXT("0.0"));
	m_SpinBoneAngle.SetRange(-100, 100);
	m_SpinBoneAngle.SetPos(0);

	cb_boneAxis.InsertString(0, TEXT("X"));
	cb_boneAxis.InsertString(1, TEXT("Y"));
	cb_boneAxis.InsertString(2, TEXT("Z"));
	cb_boneAxis.SetCurSel(0);

	m_strBoneAngle = CString();
}

BEGIN_MESSAGE_MAP(CChildForm, CFormView)
	ON_BN_CLICKED(IDC_TEST_BUTTON, &CChildForm::OnBnClickedTestButton)
	ON_WM_CREATE()
	ON_WM_ACTIVATE()
	ON_CBN_SELCHANGE(IDC_COMBO1, &CChildForm::OnCbnSelchangeCombo1)
	ON_NOTIFY(TVN_SELCHANGED, IDC_BONE_TREE, &CChildForm::OnTvnSelchangedBoneTree)
	ON_NOTIFY(UDN_DELTAPOS, SPIN_ROOT_BONE_POS_X, &CChildForm::OnDeltaposRootBonePosX)
	ON_NOTIFY(UDN_DELTAPOS, SPIN_ROOT_BONE_POS_Y, &CChildForm::OnDeltaposRootBonePosY)
	ON_NOTIFY(UDN_DELTAPOS, SPIN_ROOT_BONE_POS_Z, &CChildForm::OnDeltaposRootBonePosZ)
	ON_EN_CHANGE(EIDT_ROOT_BONE_POS_X, &CChildForm::OnEnChangeRootBonePosX)
	ON_EN_CHANGE(EIDT_ROOT_BONE_POS_Y, &CChildForm::OnEnChangeRootBonePosY)
	ON_EN_CHANGE(EIDT_ROOT_BONE_POS_Z, &CChildForm::OnEnChangeRootBonePosZ)
	ON_EN_CHANGE(EDIT_BONE_ANGLE, &CChildForm::OnEnChangeBoneAngle)
	ON_NOTIFY(UDN_DELTAPOS, SPIN_BONE_ANGLE, &CChildForm::OnDeltaposBoneAngle)
	ON_CBN_SELCHANGE(CB_ROOT_BONE_AXIS, &CChildForm::OnCbnSelchangeRootBoneAxis)
	ON_CBN_EDITUPDATE(CB_ROOT_BONE_AXIS, &CChildForm::OnCbnEditupdateRootBoneAxis)
	ON_CBN_DROPDOWN(CB_ROOT_BONE_AXIS, &CChildForm::OnCbnDropdownRootBoneAxis)
END_MESSAGE_MAP()


// CChildForm diagnostics

#ifdef _DEBUG
void CChildForm::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CChildForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG

void CChildForm::OnBnClickedTestButton()
{
	MessageBox(L"Hello World");
}


int CChildForm::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}

void CChildForm::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
}

void CChildForm::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CFormView::OnActivate(nState, pWndOther, bMinimized);
	// TODO: Add your message handler code here
}


void CChildForm::OnCbnSelchangeCombo1()
{
	// TODO: Add your control notification handler code here
}


void CChildForm::OnTvnSelchangedBoneTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);

	CString strItem = m_treeBone.GetItemText(pNMTreeView->itemNew.hItem);

	if (!strItem.Compare(KEY_BONE_ROOT))
	{
		m_iBoneIndex = 0;
	}
	else if (!strItem.Compare(KEY_BONE_PELVIS))
	{
		m_iBoneIndex = 1;
	}
	else if (!strItem.Compare(KEY_BONE_SPINE))
	{
		m_iBoneIndex = 2;
	}
	else if (!strItem.Compare(KEY_BONE_NECK))
	{
		m_iBoneIndex = 3;
	}
	else if (!strItem.Compare(KEY_BONE_LEFTLEG))
	{
		m_iBoneIndex = 4;
	}
	else if (!strItem.Compare(KEY_BONE_RIGHTLEG))
	{
		m_iBoneIndex = 5;
	}
	else if (!strItem.Compare(KEY_BONE_LEFTARM))
	{
		m_iBoneIndex = 6;
	}
	else if (!strItem.Compare(KEY_BONE_RIGHTARM))
	{
		m_iBoneIndex = 7;
	}
	else if (!strItem.Compare(KEY_BONE_LEFTELBOW))
	{
		m_iBoneIndex = 8;
	}
	else if (!strItem.Compare(KEY_BONE_RIGHTELBOW))
	{
		m_iBoneIndex = 9;
	}
	else if (!strItem.Compare(KEY_BONE_LEFTANKLE))
	{
		m_iBoneIndex = 10;
	}
	else if (!strItem.Compare(KEY_BONE_RIGHTANKLE))
	{
		m_iBoneIndex = 11;
	}

	*pResult = 0;
}

void CChildForm::OnDeltaposRootBonePosX(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	float fVal = pNMUpDown->iPos * 0.1 + pNMUpDown->iDelta* 0.1;

	if ((-100.f <= fVal) && (100.f >= fVal))
	{
		CString sValue;
		sValue.Format(_T("%3.2f"), fVal);
		m_strRootBonePosX = sValue;
		m_tbRootBonePosX.SetWindowTextW(sValue);
	}
	*pResult = 0;
}

void CChildForm::OnDeltaposRootBonePosY(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	float fVal = pNMUpDown->iPos * 0.1 + pNMUpDown->iDelta* 0.1;

	if ((-100.f <= fVal) && (100.f >= fVal))
	{
		CString sValue;
		sValue.Format(_T("%3.2f"), fVal);
		m_strRootBonePosY = sValue;
		m_tbRootBonePosY.SetWindowTextW(sValue);
	}
	*pResult = 0;
}

void CChildForm::OnDeltaposRootBonePosZ(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	float fVal = pNMUpDown->iPos * 0.1 + pNMUpDown->iDelta* 0.1;

	if ((-100.f <= fVal) && (100.f >= fVal))
	{
		CString sValue;
		sValue.Format(_T("%3.2f"), fVal);
		m_strRootBonePosZ = sValue;
		m_tbRootBonePosZ.SetWindowTextW(sValue);
	}
	*pResult = 0;
}

void CChildForm::AllowOnlyRealNum(CEdit *cedit, bool minus, CString& _String)
{
	//// [ 1. initialize value ]
	CString cstrText;
	cedit->GetWindowTextW(cstrText);
	TCHAR chText[100] = {'0', };
	lstrcpy(chText, cstrText);
	int count = lstrlen(chText);

	//// [ 2. remove second point ]
	bool pointChecker = false;
	for (int i = 0; i < count; i++) {
		if (!pointChecker && chText[i] == '.') pointChecker = true;
		else if (pointChecker && chText[i] == '.') chText[i] = NULL;
	}

	//// [ 3. remove middle of minuse ]
	int startIdx = (minus) ? 1 : 0;
	for (int i = startIdx; i < count; i++) {
		if (chText[i] == '-') chText[i] = NULL;
	}

	//// [ 4. remove character ]
	for (int i = 0; i < count; i++) {
		if (!(chText[i] >= 48 && chText[i] <= 57)) {
			if (chText[i] != '.' && chText[i] != '-') chText[i] = NULL;
		}
	}

	//// [ 5. Set text ]
	int n = _String.Compare(chText);
	if (0 != _String.Compare(chText))
	{
		_String = chText;
		cedit->SetWindowTextW(chText);
		//// [ 6. Move cursor to end ]
		cedit->SetSel(0, 0);
		cedit->SetSel(-1, -1);
	}

}

void CChildForm::OnEnChangeRootBonePosX()
{
	AllowOnlyRealNum(&m_tbRootBonePosX, true, m_strRootBonePosX);
	CString str;
	m_tbRootBonePosX.GetWindowTextW(str);

	float fValue = _tstof(str);
	g_vecBoneTransfrom[m_iBoneIndex]->Set_LocalPos(fValue, Engine::AXISX);
}


void CChildForm::OnEnChangeRootBonePosY()
{
	AllowOnlyRealNum(&m_tbRootBonePosY, true, m_strRootBonePosY);
	CString str;
	m_tbRootBonePosY.GetWindowTextW(str);

	float fValue = _tstof(str);
	g_vecBoneTransfrom[m_iBoneIndex]->Set_LocalPos(fValue, Engine::AXISY);
}


void CChildForm::OnEnChangeRootBonePosZ()
{
	AllowOnlyRealNum(&m_tbRootBonePosZ, true, m_strRootBonePosZ);
	CString str;
	m_tbRootBonePosZ.GetWindowTextW(str);

	float fValue = _tstof(str);
	g_vecBoneTransfrom[m_iBoneIndex]->Set_LocalPos(fValue, Engine::AXISZ);
}


void CChildForm::OnEnChangeBoneAngle()
{
	AllowOnlyRealNum(&m_tbBoneAngle, true, m_strBoneAngle);
	CString str;
	m_tbBoneAngle.GetWindowTextW(m_strBoneAngle);

	float fValue = _tstof(m_strBoneAngle);
	m_fBoneLocalAngle = fValue;
	g_vecBoneTransfrom[m_iBoneIndex]->Set_LocalXYZMatrix(m_vBoneLocalAxis, m_fBoneLocalAngle);
}


void CChildForm::OnDeltaposBoneAngle(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	float fVal = pNMUpDown->iPos * 0.1 + pNMUpDown->iDelta* 0.1;

	if ((-100.f <= fVal) && (100.f >= fVal))
	{
		CString sValue;
		sValue.Format(_T("%3.2f"), fVal);
		m_strBoneAngle = sValue;
		m_tbBoneAngle.SetWindowTextW(sValue);
	}
	*pResult = 0;
}

void CChildForm::OnCbnSelchangeRootBoneAxis()
{
}


void CChildForm::OnCbnEditupdateRootBoneAxis()
{
	if (AXISX == cb_boneAxis.GetCurSel())
	{
		m_vBoneLocalAxis = D3DXVECTOR3(1.f, 0.f, 0.f);
	}
	else if (AXISY == cb_boneAxis.GetCurSel())
	{
		m_vBoneLocalAxis = D3DXVECTOR3(0.f, 1.f, 0.f);
	}
	else if (AXISZ == cb_boneAxis.GetCurSel())
	{
		m_vBoneLocalAxis = D3DXVECTOR3(0.f, 0.f, 1.f);
	}
}


void CChildForm::OnCbnDropdownRootBoneAxis()
{
	if (AXISX == cb_boneAxis.GetCurSel())
	{
		m_vBoneLocalAxis = D3DXVECTOR3(1.f, 0.f, 0.f);
	}
	else if (AXISY == cb_boneAxis.GetCurSel())
	{
		m_vBoneLocalAxis = D3DXVECTOR3(0.f, 1.f, 0.f);
	}
	else if (AXISZ == cb_boneAxis.GetCurSel())
	{
		m_vBoneLocalAxis = D3DXVECTOR3(0.f, 0.f, 1.f);
	}
}
