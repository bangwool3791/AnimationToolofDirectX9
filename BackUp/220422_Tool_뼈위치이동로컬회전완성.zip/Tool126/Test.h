#pragma once
#include "GameObject.h"
#include "Renderer.h"
#include "VIBuffer_Cube.h"
#include "GameInstance.h"

class CTest final : public CGameObject
{
public :
	enum TEST_STATE{TEST_STATE_IDLE, TEST_STATE_STUN, TEST_STATE_ATTACK, TEST_STATE_DIE, TEST_STATE_END};

	TEST_STATE m_eTestState = TEST_STATE_IDLE;

	enum ANIMATION_STATE{ROOT, PELVIS, SPINE, NECK, LEFTLEG, RIGHTLEG, LEFTARM, RIGHTARM, LEFTELBOW, RIGHTELBOW, LEFTANKLE, RIGHTANKLE, ANIMATION_STATE_END};
	enum INVERSE_ANIMATION_STATE {
		INV_RIGHTANKLE , INV_LEFTANKLE, INV_RIGHTLBOW, INV_LEFTELBOW, INV_RIGHTARM, INV_LEFTARM, INV_RIGHTLEG, INV_LEFTLEG,
		INV_NECK, INV_SPINE, INV_PELVIS, INV_ROOT};

	enum ANIMATION_PLAY{ANI_PLAY, ANI_SET, ANI_END};
	enum INVERSE_ANIMATION_PLAY { INV_ANI_END, INV_ANI_SET, INV_ANI_PLAY };

	enum DIR_STATE{XAXIS, YAXIS, ZASIX, PLUS, MINUS, DIR_STATE_END};
	enum INVERSE_DIR_STATE {INV_MINUS, INV_PLUS, INV_ZAXIS, INV_YAXIS, INV_XAXIS};
	//flag Set�� �ʱ�ȭ �ϴ� �Լ� �ʿ�.
	typedef struct tagTestStruct
	{
		//������ ������ ���� �ʿ�.
		//1111 1111
		//root - pelvis - spine - neck - leftleg - rightleg - leftarm - rightarm
		_Uint32t uMotion = 0;
		//0001 1111
		//x axis - y axis - z axis - plus - minus
		_Uint32t uDir[ANIMATION_STATE_END];
		//Set Trans class the Angle
		_float fAngle[ANIMATION_STATE_END];
		_Uint32t uFlag[ANIMATION_STATE_END];
		tagTestStruct::tagTestStruct()
		{
			for (int i = 0; i < ANIMATION_STATE_END; ++i)
			{
				uDir[i] = 0x00;
				fAngle[i] = 0.f;
				uFlag[i] = 0x00;
			}
		}
	}TEST_STRUCT;
private :
	FORCEINLINE void Clear_Flag(TEST_STATE eState, _float _fDeltaTime)
	{
		m_pBone->Clear_BoneAngle(Engine::BONE_LAYER_PLAYER);

		if (m_vecTestState[m_eTestState].uFlag[ROOT] >> INV_ANI_SET & 0x01)
			m_pBoneRootTransForm->Turn_Local(m_varr[ROOT], _fDeltaTime);
		if (m_vecTestState[m_eTestState]
			.uFlag[PELVIS] >> INV_ANI_SET & 0x01)
			m_pBonePelvisTransForm->Turn_Local(m_varr[PELVIS], _fDeltaTime);
		if (m_vecTestState[m_eTestState].uFlag[SPINE] >> INV_ANI_SET & 0x01)
			m_pBoneSpineTransForm->Turn_Local(m_varr[SPINE], _fDeltaTime);
		if (m_vecTestState[m_eTestState].uFlag[LEFTLEG] >> INV_ANI_SET & 0x01)
			m_pBoneLeftLegTransForm->Turn_Local(m_varr[LEFTLEG], _fDeltaTime);
		if (m_vecTestState[m_eTestState].uFlag[RIGHTLEG] >> INV_ANI_SET & 0x01)
			m_pBoneRightLegTransForm->Turn_Local(m_varr[RIGHTLEG], _fDeltaTime);
		if (m_vecTestState[m_eTestState].uFlag[LEFTARM] >> INV_ANI_SET & 0x01)
			m_pBoneLeftArmTransForm->Turn_Local(m_varr[LEFTARM], _fDeltaTime);
		if (m_vecTestState[m_eTestState].uFlag[RIGHTARM] >> INV_ANI_SET & 0x01)
			m_pBoneRightArmTransForm->Turn_Local(m_varr[RIGHTARM], _fDeltaTime);

		for (int i = 0; i < ANIMATION_STATE_END; ++i)
		{
			m_vecTestState[eState].uFlag[i] = 0x00;
		}
		m_eTestState = TEST_STATE_IDLE;
	}
private :
//	vector<>
	vector<TEST_STRUCT> m_vecTestState;
	_float3 m_varr[ANIMATION_STATE_END];
	_float m_farr[ANIMATION_STATE_END];
public:
	explicit CTest::CTest(LPDIRECT3DDEVICE9 _pDevice)
		:CGameObject(_pDevice)
	{
	}

	explicit CTest::CTest(const CTest& _rhs)
		: CGameObject(_rhs)
	{
	}

	virtual ~CTest() = default;
public:
	virtual void Tick(_float _fDeltaTime) override;
	virtual void Late_Tick(_float _fDeltaTime) override;
	virtual HRESULT Render() override;
protected:
	virtual HRESULT NativeConstruct_Prototype() override;
	virtual HRESULT NativeConstruct(void* pArg) override;
private :
	void Set_Animation(ANIMATION_STATE eState, _float3& vAxis, _float fDir, CTransform* _pTransForm)
	{
		if (!(m_vecTestState[m_eTestState].uFlag[eState] >> INV_ANI_SET))
		{
			if (m_vecTestState[m_eTestState].uDir[eState] >> INV_XAXIS && 0x01)
				vAxis.x = TRUE;
			else if (m_vecTestState[m_eTestState].uDir[eState] >> INV_YAXIS & 0x01)
				vAxis.y = TRUE;
			else if (m_vecTestState[m_eTestState].uDir[eState] >> INV_ZAXIS & 0x01)
				vAxis.z = TRUE;

			if (m_vecTestState[m_eTestState].uDir[eState] >> INV_PLUS & 0x01)
				fDir = 1.f;
			else if (m_vecTestState[m_eTestState].uDir[eState] >> INV_MINUS & 0x01)
				fDir = -1.f;

			m_vecTestState[m_eTestState].uFlag[eState] = 0x01 << (INV_ANI_SET);

			_pTransForm->Set_Animation(m_vecTestState[m_eTestState].fAngle[eState], fDir);
		}
	}

private:
	HRESULT SetUp_Components();
	//root
	CTransform* m_pBoneRootTransForm = NULL;
	//pelvis
	CTransform* m_pBonePelvisTransForm = NULL;
	//spine
	CTransform* m_pBoneSpineTransForm = NULL;
	//neck
	CTransform* m_pBoneNeckTransForm = NULL;
	//left leg
	CTransform* m_pBoneLeftLegTransForm = NULL;
	//right leg
	CTransform* m_pBoneRightLegTransForm = NULL;
	//left arm
	CTransform* m_pBoneLeftArmTransForm = NULL;
	//Right arm
	CTransform* m_pBoneRightArmTransForm = NULL;
	//Left Elbow
	CTransform* m_pBoneLeftElbowTransForm = NULL;
	//Right Elbow
	CTransform* m_pBoneRightElbowTransForm = NULL;
	//Left Ankle
	CTransform* m_pBoneLeftAnkleTransForm = NULL;
	//Right Ankle
	CTransform* m_pBoneRightAnkleTransForm = NULL;

	//Ani VIBuffer Member Pointer
	//head
	CVIBuffer_Cube* m_pAniHeadCube = NULL;
	//body
	CVIBuffer_Cube* m_pAniBodyCube = NULL;
	//left leg
	CVIBuffer_Cube* m_pAniLeftLegCube = NULL;
	//right leg
	CVIBuffer_Cube* m_pAniRightLegCube = NULL;
	//left arm
	CVIBuffer_Cube* m_pAniLeftArmCube = NULL;
	//Right arm
	CVIBuffer_Cube* m_pAniRightArmCube = NULL;
	//Left Elbow
	CVIBuffer_Cube* m_pAniLeftElbowCube = NULL;
	//Right Elbow
	CVIBuffer_Cube* m_pAniRightElbowCube = NULL;
	//Left Ankle
	CVIBuffer_Cube* m_pAniLeftAnkleCube = NULL;
	//Right Ankle
	CVIBuffer_Cube* m_pAniRightAnkleCube = NULL;
private :
	CBone * m_pBone = NULL;
	public :
		void Mouse_X(_float _fDeltaTime, _float _MouseMove)
		{
			m_pBoneRootTransForm->Turn(m_pBoneRootTransForm->Get_State(STATE_RIGHT), _fDeltaTime * _MouseMove * 0.1f);
		}

		void Mouse_Y(_float _fDeltaTime, _float _MouseMove)
		{
			m_pBoneRootTransForm->Turn(_float3(0.f, 1.f, 0.f), _fDeltaTime * _MouseMove * 0.1f);
		}

public:
	FORCEINLINE static CTest* CTest::Create(LPDIRECT3DDEVICE9 _pDevice)
	{
		CTest * pInstance = new CTest(_pDevice);
		if (!pInstance)
			return NULL;

		if (FAILED(pInstance->NativeConstruct_Prototype()))
			return NULL;

		return pInstance;
	}
	virtual CTest* Clone(void* pArg);
	virtual void Free();
};

